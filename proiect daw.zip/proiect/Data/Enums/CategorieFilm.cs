﻿namespace proiect.Data.Enums
{
    public enum CategorieFilm
    {
        Actiune = 1,
        Comedie,
        Drama,
        Documentar,
        Desene,
        Horror
    }
}
