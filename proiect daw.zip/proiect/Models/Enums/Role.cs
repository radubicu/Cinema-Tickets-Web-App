﻿namespace proiect.Models.Enums
{
    public enum Role
    {
        Admin,
        User
    }
}
