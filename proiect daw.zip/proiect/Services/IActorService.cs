﻿namespace proiect.Services
{
    public class IActorService
    {
    }
}
