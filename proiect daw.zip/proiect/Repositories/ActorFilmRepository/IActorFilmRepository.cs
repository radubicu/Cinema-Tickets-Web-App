using proiect.Models;
using proiect.Repositories.GenericRepository;

namespace proiect.Repositories.EmployeeStoreRepository
{
  public interface IActorFilmRepository : IGenericRepository<Actor_Film>
  {
  }
}
