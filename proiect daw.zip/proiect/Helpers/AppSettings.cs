namespace proiect.Helpers
{
  public class AppSettings
  {
    public string? JwtToken { get; set; }
  }
}
